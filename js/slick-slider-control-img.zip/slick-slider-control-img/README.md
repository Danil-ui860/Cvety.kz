# Slick Slider Control IMG

A Pen created on CodePen.io. Original URL: [https://codepen.io/wikyware-net/pen/WNXwvEO](https://codepen.io/wikyware-net/pen/WNXwvEO).

